package com.aischool.model;

import java.util.Date;

public class BoardTB {
    private int boardId;
    private String category;
    private String title;
    private String content;
    private Date regDate;
    private String userEmpid;

    // 생성자
    public BoardTB() {}

    public BoardTB(int boardId, String category, String title, String content, Date regDate, String userEmpid) {
        this.boardId = boardId;
        this.category = category;
        this.title = title;
        this.content = content;
        this.regDate = regDate;
        this.userEmpid = userEmpid;
    }

    // Getter와 Setter 메서드
    public int getBoardId() { return boardId; }
    public void setBoardId(int boardId) { this.boardId = boardId; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }

    public Date getRegDate() { return regDate; }
    public void setRegDate(Date regDate) { this.regDate = regDate; }

    public String getUserEmpid() { return userEmpid; }
    public void setUserEmpid(String userEmpid) { this.userEmpid = userEmpid; }
}