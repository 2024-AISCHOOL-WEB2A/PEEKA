package com.aischool.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class VacationDAO {

	private Connection conn;
	private PreparedStatement pst;
	private ResultSet rs;

	// 데이터베이스 연결기능
	public void connect() {

		try {

			Class.forName("oracle.jdbc.driver.OracleDriver");

			String url = "jdbc:oracle:thin:@project-db-stu3.smhrd.com:1524:xe";
			String id = "Insa5_SpringA_hacksim_1";
			String pw = "aishcool1";

			conn = DriverManager.getConnection(url, id, pw);

			if (conn != null) {
				System.out.println("Connection 성공");
			} else {
				System.out.println("Connection 실패");
			}

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// 데이터베이스 연결종료 기능
	public void close() {

		try {
			if (rs != null) {
				rs.close();
			}

			if (pst != null) {
				pst.close();
			}

			if (conn != null) {
				conn.close();
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	// 1. 휴가 신청자
	public VacationTB EmpOffday(String empid) {
		VacationTB offday = null;
		connect();

		try {
			String sql = "SELECT * FROM VACATION_TB WHERE USER_EMPID=?";
			pst = conn.prepareStatement(sql);
			pst.setString(1, empid);

			rs = pst.executeQuery();

			if (rs.next()) {
				offday = new VacationTB();
				offday.setIdx(rs.getInt("VAC_IDX"));
				offday.setEmpid(rs.getString("USER_EMPID"));
				offday.setYear(rs.getString("VAC_YEAR"));
				offday.setYYoffday(rs.getDouble("YY_CNT"));
				offday.setDept_manager(rs.getString("DEPT_MANAGER"));
				offday.setDept_name(rs.getString("DEPT_NAME"));
				offday.setStartDate(rs.getString("START_DATE"));
				offday.setEndDate(rs.getString("END_DATE"));
				offday.setReason(rs.getString("REASON"));
				offday.setStatus(rs.getString("STATUS"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}

		return offday;
	}

	// 휴가 신청 추가 메서드
	public boolean addVacation(VacationTB vacation) {
		boolean success = false;
		try {
			connect();
			String sql = "INSERT INTO VACATION_TB (VAC_IDX, USER_EMPID, VAC_YEAR, YY_CNT, DEPT_MANAGER, DEPT_NAME, START_DATE, END_DATE, REASON, STATUS) "
					+ "VALUES (VACATION_SEQ.NEXTVAL, ?, ?, ?, ?, ?, TO_DATE(?, 'YYYY-MM-DD'), TO_DATE(?, 'YYYY-MM-DD'), ?, ?)";
			pst = conn.prepareStatement(sql);
			pst.setString(1, vacation.getEmpid());
			pst.setString(2, vacation.getYear());
			pst.setDouble(3, vacation.getYYoffday());
			pst.setString(4, vacation.getDept_manager() != null ? vacation.getDept_manager() : "DEFAULT_MANAGER");
			pst.setString(5, vacation.getDept_name());
			pst.setString(6, vacation.getStartDate());
			pst.setString(7, vacation.getEndDate());
			pst.setString(8, vacation.getReason());
			pst.setString(9, vacation.getStatus());

			int result = pst.executeUpdate();
			success = (result > 0);
			System.out.println("휴가 신청 SQL 실행 결과: " + result);
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("SQL 예외 발생 in addVacation: " + e.getMessage());
		} finally {
			close();
		}
		return success;
	}

	// 부서장별 대기 중인 휴가 신청 조회 메서드
	public List<VacationTB> getPendingVacationsByManager(String managerEmpId) {
		List<VacationTB> pendingVacations = new ArrayList<>();
		try {
			connect();
			String sql = "SELECT * FROM VACATION_TB WHERE DEPT_MANAGER = ? AND STATUS = 'PENDING'";
			pst = conn.prepareStatement(sql);
			pst.setString(1, managerEmpId);
			rs = pst.executeQuery();

			while (rs.next()) {
				VacationTB vacation = new VacationTB();
				vacation.setIdx(rs.getInt("IDX"));
				vacation.setEmpid(rs.getString("EMPID"));
				vacation.setYear(rs.getString("YEAR"));
				vacation.setYYoffday(rs.getDouble("YYOFFDAY"));
				vacation.setDept_manager(rs.getString("DEPT_MANAGER"));
				vacation.setDept_name(rs.getString("DEPT_NAME"));
				vacation.setStartDate(rs.getString("START_DATE"));
				vacation.setEndDate(rs.getString("END_DATE"));
				vacation.setReason(rs.getString("REASON"));
				vacation.setStatus(rs.getString("STATUS"));
				pendingVacations.add(vacation);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return pendingVacations;
	}

	// 휴가 승인/거절 메서드
	public boolean updateVacationStatus(int vacationId, String status) {
		boolean success = false;
		try {
			connect();
			String sql = "UPDATE VACATION_TB SET STATUS = ? WHERE IDX = ?";
			pst = conn.prepareStatement(sql);
			pst.setString(1, status);
			pst.setInt(2, vacationId);

			int result = pst.executeUpdate();
			success = (result > 0);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return success;
	}

	public List<VacationTB> getPendingVacations() {
		List<VacationTB> pendingVacations = new ArrayList<>();
		try {
			connect();
			String sql = "SELECT * FROM VACATION_TB WHERE STATUS = 'PENDING'";
			pst = conn.prepareStatement(sql);
			rs = pst.executeQuery();

			while (rs.next()) {
				VacationTB vacation = new VacationTB();
				vacation.setIdx(rs.getInt("VAC_IDX"));
				vacation.setEmpid(rs.getString("USER_EMPID"));
				vacation.setYear(rs.getString("VAC_YEAR"));
				vacation.setYYoffday(rs.getDouble("YY_CNT"));
				vacation.setDept_manager(rs.getString("DEPT_MANAGER"));
				vacation.setDept_name(rs.getString("DEPT_NAME"));
				vacation.setStartDate(rs.getDate("START_DATE").toString());
				vacation.setEndDate(rs.getDate("END_DATE").toString());
				vacation.setReason(rs.getString("REASON"));
				vacation.setStatus(rs.getString("STATUS"));
				pendingVacations.add(vacation);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return pendingVacations;
	}

	// approveVacation 메서드는 그대로 유지하되, VAC_IDX를 사용하도록 수정
	public void approveVacation(int vacationId) throws SQLException {
		try {
			connect();
			String sql = "UPDATE VACATION_TB SET STATUS = 'APPROVED' WHERE VAC_IDX = ?";
			pst = conn.prepareStatement(sql);
			pst.setInt(1, vacationId);
			pst.executeUpdate();
		} finally {
			close();
		}
	}

	public void addApprovedVacationToCalendar(int vacationId) throws SQLException {
		try {
			connect();
			String sql = "INSERT INTO CALENDAR_TB (VAC_IDX, STATUS) SELECT VAC_IDX, 'APPROVED' FROM VACATION_TB WHERE VAC_IDX = ?";
			pst = conn.prepareStatement(sql);
			pst.setInt(1, vacationId);
			pst.executeUpdate();
		} finally {
			close();
		}
	}
	
	public List<VacationTB> getApprovedVacations() {
	    List<VacationTB> approvedVacations = new ArrayList<>();
	    try {
	        connect();
	        String sql = "SELECT * FROM VACATION_TB WHERE STATUS = 'APPROVED'";
	        pst = conn.prepareStatement(sql);
	        rs = pst.executeQuery();

	        while (rs.next()) {
	            VacationTB vacation = new VacationTB();
	            vacation.setIdx(rs.getInt("VAC_IDX"));
	            vacation.setEmpid(rs.getString("USER_EMPID"));
	            vacation.setStartDate(rs.getString("START_DATE"));
	            vacation.setEndDate(rs.getString("END_DATE"));
	            vacation.setReason(rs.getString("REASON"));
	            approvedVacations.add(vacation);
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    } finally {
	        close();
	    }
	    return approvedVacations;
	}
	
	public List<VacationTB> getTodayVacations() {
	    List<VacationTB> todayVacations = new ArrayList<>();
	    try {
	        connect();
	        String sql = "SELECT v.*, m.USER_NAME FROM VACATION_TB v JOIN MEMBER_TB m ON v.USER_EMPID = m.USER_EMPID WHERE TRUNC(SYSDATE) BETWEEN v.START_DATE AND v.END_DATE AND v.STATUS = 'APPROVED'";
	        pst = conn.prepareStatement(sql);
	        rs = pst.executeQuery();
	        while (rs.next()) {
	            VacationTB vacation = new VacationTB();
	            vacation.setEmpid(rs.getString("USER_EMPID"));
	            vacation.setStartDate(rs.getString("START_DATE"));
	            vacation.setEndDate(rs.getString("END_DATE"));
	            vacation.setReason(rs.getString("REASON"));
	            vacation.setUserName(rs.getString("USER_NAME"));
	            todayVacations.add(vacation);
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    } finally {
	        close();
	    }
	    return todayVacations;
	}

}