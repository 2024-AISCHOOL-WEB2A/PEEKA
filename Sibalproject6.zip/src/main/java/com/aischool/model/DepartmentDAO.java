package com.aischool.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DepartmentDAO {
    private static final String URL = "jdbc:oracle:thin:@project-db-stu3.smhrd.com:1524:xe";
    private static final String USER = "Insa5_SpringA_hacksim_1";
    private static final String PASSWORD = "aishcool1";

    private Connection conn;
    private PreparedStatement pst;
    private ResultSet rs;

    // 데이터베이스 연결 메서드
    private Connection getConnection() throws SQLException {
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (ClassNotFoundException e) {
            throw new SQLException("JDBC 드라이버를 찾을 수 없습니다.", e);
        }
    }

    // 데이터베이스 연결 종료 메서드
    private void close() {
        try {
            if (rs != null) rs.close();
            if (pst != null) pst.close();
            if (conn != null) conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // 직원 ID로 부서 정보 조회 메서드
    public DepartmentTB getDepartmentByEmpId(String empId) {
        DepartmentTB department = null;
        try {
            conn = getConnection();
            String sql = "SELECT d.* FROM DEPARTMENT_TB d JOIN MEMBER_TB m ON d.DEPT_IDX = m.DEPT_IDX WHERE m.USER_EMPID = ?";
            pst = conn.prepareStatement(sql);
            pst.setString(1, empId);
            
            System.out.println("Executing SQL: " + sql);
            System.out.println("With parameter: " + empId);
            
            rs = pst.executeQuery();

            if (rs.next()) {
                department = new DepartmentTB();
                department.setDept_idx(rs.getInt("DEPT_IDX"));
                department.setDept_Name(rs.getString("DEPT_NAME"));
                department.setDept_Location(rs.getString("DEPT_LOC"));
                department.setDept_Space(rs.getString("DEPT_SPACE"));
                department.setDept_Manager(rs.getString("DEPT_MANAGER"));
                
                System.out.println("Found department: " + department);
                System.out.println("DEPT_MANAGER: " + department.getDept_Manager());
            } else {
                System.out.println("No department found for empId: " + empId);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("SQL Exception in getDepartmentByEmpId: " + e.getMessage());
        } finally {
            close();
        }
        return department;
    }   
    
    public String getDepartmentNameById(String deptId) {
        String deptName = null;
        try {
            conn = getConnection();
            String sql = "SELECT DEPT_NAME FROM DEPARTMENT_TB WHERE DEPT_IDX = ?";
            pst = conn.prepareStatement(sql);
            pst.setString(1, deptId);
            rs = pst.executeQuery();
            if (rs.next()) {
                deptName = rs.getString("DEPT_NAME");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            close();
        }
        return deptName;
    }
    
    
}