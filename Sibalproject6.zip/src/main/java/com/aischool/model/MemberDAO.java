package com.aischool.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

// DAO(Data Access Object)
// 데이터베이스 관련 기능을 관리하는 객체
// 1. Connection객체
// 2. PreparedStatement객체
// 3. ResultSet객체
public class MemberDAO {

	private Connection conn;
	private PreparedStatement pst;
	private ResultSet rs;

	// 데이터베이스 연결기능
	public void connect() {

		try {
			// 1. OracleDriver 동적 로딩
			Class.forName("oracle.jdbc.driver.OracleDriver");

			// 2. Connection객체 생성(DB연결)
			// - url, user, password 필요

			String url = "jdbc:oracle:thin:@project-db-stu3.smhrd.com:1524:xe";
			String id = "Insa5_SpringA_hacksim_1";
			String pw = "aishcool1";

			conn = DriverManager.getConnection(url, id, pw);

			if (conn != null) {
				System.out.println("Connection 성공");
			} else {
				System.out.println("Connection 실패");
			}

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// 데이터베이스 연결종료 기능
	public void close() {

		try {
			if (rs != null) {
				rs.close();
			}

			if (pst != null) {
				pst.close();
			}

			if (conn != null) {
				conn.close();
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	// 회원가입 기능
	public int memberJoin(WebMember member) {
		// 1. DB연결
		connect();
		int cnt = 0;

		System.out.println(member.toString());

		try {
			// Empid 중복 체크
			String checkSql = "SELECT COUNT(*) FROM MEMBER_TB WHERE USER_empid = ?";
			pst = conn.prepareStatement(checkSql);
			pst.setString(1, member.getEmpid());
			ResultSet rs = pst.executeQuery();

			if (rs.next() && rs.getInt(1) > 0) {
				return -1; // Empid가 이미 존재하면 -1 반환
			}

			String sql = "INSERT INTO MEMBER_TB(USER_EMPID, USER_PW, USER_NAME, USER_EMAIL, USER_BIRTHDATE, HIRED_AT, USER_PHONE, USER_INLINE, DEPT_IDX, USER_POSITION, LAST_LOGIN, USER_ROLE, REMAINING_LEAVE) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
			pst = conn.prepareStatement(sql);

			pst.setString(1, member.getEmpid());
			pst.setString(2, member.getPw());
			pst.setString(3, member.getName());
			pst.setString(4, member.getEmail());

			// 날짜 처리
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			LocalDate birthDate = LocalDate.parse(member.getBirthday(), formatter);
			LocalDate hireDate = LocalDate.parse(member.getHiredate(), formatter);

			pst.setDate(5, java.sql.Date.valueOf(birthDate));
			pst.setDate(6, java.sql.Date.valueOf(hireDate));

			pst.setString(7, member.getPhone());
			pst.setString(8, member.getInlinenum());
			pst.setInt(9, Integer.parseInt(member.getDeptidx())); // DEPT_IDX는 NUMBER 타입이므로 int로 변환
			pst.setString(10, member.getPosition());

			// LAST_LOGIN은 DATE 타입이므로 현재 날짜만 저장
			LocalDate currentDate = LocalDate.now();
			pst.setDate(11, java.sql.Date.valueOf(currentDate));

			pst.setString(12, member.getRole());
			pst.setDouble(13, 15.0); // REMAINING_LEAVE의 기본값

			cnt = pst.executeUpdate();

			// LAST_LOGIN을 WebMember 객체에도 설정
			member.setLastlogin(currentDate.toString());
			member.setRemainingLeave(15.0);

			System.out.println("Member joined successfully: " + member.toString());

		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("SQL Exception: " + e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Exception: " + e.getMessage());
		} finally {
			close();
		}

		return cnt;
	}

	public int getDeptIdxByName(String deptName) {
		int deptIdx = 0;
		connect();
		try {
			String sql = "SELECT DEPT_IDX FROM DEPARTMENT_TB WHERE DEPT_NAME = ?";
			pst = conn.prepareStatement(sql);
			pst.setString(1, deptName);
			rs = pst.executeQuery();
			if (rs.next()) {
				deptIdx = rs.getInt("DEPT_IDX");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return deptIdx;
	}

	// 로그인 서비스
	public WebMember memberLogin(WebMember member) {
		WebMember mem = null;
		connect();

		try {
			String sql = "SELECT * FROM MEMBER_TB WHERE USER_EMPID=? AND USER_PW=?";
			pst = conn.prepareStatement(sql);
			pst.setString(1, member.getEmpid());
			pst.setString(2, member.getPw());

			rs = pst.executeQuery();

			if (rs.next()) {
				mem = new WebMember();
				mem.setEmpid(rs.getString("USER_EMPID"));
				mem.setName(rs.getString("USER_NAME"));
				mem.setEmail(rs.getString("USER_EMAIL"));
				mem.setDeptidx(rs.getString("DEPT_IDX"));
				mem.setPosition(rs.getString("USER_POSITION"));
				mem.setRole(rs.getString("USER_ROLE"));
				mem.setRemainingLeave(rs.getDouble("REMAINING_LEAVE"));

				// 현재 시간을 가져옵니다
				LocalDateTime currentTime = LocalDateTime.now();
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
				String formattedDateTime = currentTime.format(formatter);

				// 로그인 시간을 출력합니다
				System.out.println("로그인 시간: " + formattedDateTime);

				// 데이터베이스에 마지막 로그인 시간을 업데이트합니다
				String updateSql = "UPDATE MEMBER_TB SET LAST_LOGIN = ? WHERE USER_EMPID = ?";
				PreparedStatement updatePst = conn.prepareStatement(updateSql);
				updatePst.setString(1, formattedDateTime);
				updatePst.setString(2, mem.getEmpid());
				updatePst.executeUpdate();
				updatePst.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}

		return mem;
	}

	// 회원 목록 조회
	public ArrayList<WebMember> memberSelect() {
		ArrayList<WebMember> list = new ArrayList<>();
		connect();

		try {
			String sql = "SELECT * FROM MEMBER_TB";
			pst = conn.prepareStatement(sql);
			rs = pst.executeQuery();

			while (rs.next()) {
				WebMember member = new WebMember();
				member.setEmpid(rs.getString("USER_EMPID"));
				member.setName(rs.getString("USER_NAME"));
				member.setDeptidx(rs.getString("DEPT_IDX"));
				member.setPhone(rs.getString("USER_PHONE"));
				member.setEmail(rs.getString("USER_EMAIL"));
				member.setPosition(rs.getString("USER_POSITION"));
				// 필요한 다른 필드들도 설정

				list.add(member);
			}
			System.out.println("Total members fetched: " + list.size());
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}

		return list;
	}

	// 회원 삭제
	public int memberDelete(String empid) {
		int cnt = 0;
		connect();
		try {
			conn.setAutoCommit(false); // 트랜잭션 시작
			String sql = "DELETE FROM MEMBER_TB WHERE USER_EMPID=?";
			pst = conn.prepareStatement(sql);
			pst.setString(1, empid);
			cnt = pst.executeUpdate();
			conn.commit(); // 트랜잭션 커밋
			System.out.println("Deleted employee with ID: " + empid + ", Result: " + cnt); // 로그 추가
		} catch (SQLException e) {
			try {
				conn.rollback(); // 오류 발생 시 롤백
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
			e.printStackTrace();
			System.out.println("SQL Exception occurred: " + e.getMessage()); // 로그 추가
		} finally {
			close();
		}
		return cnt;
	}

	public WebMember getMemberByEmpId(String empId) {
		WebMember member = null;
		try {
			connect();
			String sql = "SELECT * FROM MEMBER_TB WHERE EMPID = ?";
			pst = conn.prepareStatement(sql);
			pst.setString(1, empId);
			rs = pst.executeQuery();

			if (rs.next()) {
				member = new WebMember();
				member.setEmpid(rs.getString("EMPID"));
				member.setName(rs.getString("NAME"));
				member.setPosition(rs.getString("POSITION"));
				member.setDeptidx(rs.getString("DEPTIDX"));
				member.setRemainingLeave(rs.getDouble("REMAINING_LEAVE"));

				// 다른 필요한 필드들 설정
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return member;
	}

	// 회원 정보 수정 (새로 추가된 메서드)
	public int memberUpdate(WebMember member) {
		connect();
		int cnt = 0;
		try {
			StringBuilder sql = new StringBuilder("UPDATE MEMBER_TB SET ");
			ArrayList<String> updateFields = new ArrayList<>();
			ArrayList<Object> parameters = new ArrayList<>();

			if (member.getName() != null) {
				updateFields.add("USER_NAME=?");
				parameters.add(member.getName());
			}
			if (member.getEmail() != null) {
				updateFields.add("USER_EMAIL=?");
				parameters.add(member.getEmail());
			}
			if (member.getPhone() != null) {
				updateFields.add("USER_PHONE=?");
				parameters.add(member.getPhone());
			}
			if (member.getInlinenum() != null) {
				updateFields.add("USER_INLINE=?");
				parameters.add(member.getInlinenum());
			}
			if (member.getDeptidx() != null) {
				updateFields.add("DEPT_IDX=?");
				parameters.add(member.getDeptidx());
			}
			if (member.getPosition() != null) {
				updateFields.add("USER_POSITION=?");
				parameters.add(member.getPosition());
			}
			if (member.getPw() != null) {
				updateFields.add("USER_PW=?");
				parameters.add(member.getPw());
			}

			sql.append(String.join(", ", updateFields));
			sql.append(" WHERE USER_EMPID=?");
			parameters.add(member.getEmpid());

			pst = conn.prepareStatement(sql.toString());
			for (int i = 0; i < parameters.size(); i++) {
				pst.setObject(i + 1, parameters.get(i));
			}

			cnt = pst.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return cnt;
	}

	// 회원 정보 조회 (ID로 조회)
	public WebMember getMemberById(String empId) {
		WebMember member = null;
		connect();
		try {
			String sql = "SELECT * FROM MEMBER_TB WHERE USER_EMPID=?";
			pst = conn.prepareStatement(sql);
			pst.setString(1, empId);
			rs = pst.executeQuery();
			if (rs.next()) {
				member = new WebMember();
				member.setEmpid(rs.getString("USER_EMPID"));
				member.setName(rs.getString("USER_NAME"));
				member.setEmail(rs.getString("USER_EMAIL"));
				member.setPhone(rs.getString("USER_PHONE"));
				member.setInlinenum(rs.getString("USER_INLINE"));
				member.setDeptidx(rs.getString("DEPT_IDX"));
				member.setPosition(rs.getString("USER_POSITION"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return member;
	}
	
	public ArrayList<WebMember> getBoardList() {
	    ArrayList<WebMember> boardList = new ArrayList<>();
	    connect();
	    try {
	        String sql = "SELECT b.BOARD_ID, b.CATEGORY, b.TITLE, m.USER_NAME, b.REG_DATE " +
	                     "FROM BOARD_TB b JOIN MEMBER_TB m ON b.USER_EMPID = m.USER_EMPID " +
	                     "ORDER BY b.BOARD_ID DESC";
	        pst = conn.prepareStatement(sql);
	        rs = pst.executeQuery();
	        
	        while(rs.next()) {
	            WebMember board = new WebMember();
	            board.setBoardId(rs.getInt("BOARD_ID"));
	            board.setCategory(rs.getString("CATEGORY"));
	            board.setTitle(rs.getString("TITLE"));
	            board.setName(rs.getString("USER_NAME"));
	            board.setRegDate(rs.getDate("REG_DATE").toString());
	            boardList.add(board);
	        }
	    } catch(SQLException e) {
	        e.printStackTrace();
	    } finally {
	        close();
	    }
	    return boardList;
	}
	
	public boolean addNotice(String category, String title, String content, String userEmpid) {
	    boolean success = false;
	    try {
	        connect(); // 데이터베이스 연결
	        String sql = "INSERT INTO BOARD_TB (BOARD_ID, CATEGORY, TITLE, CONTENT, USER_EMPID, REG_DATE) VALUES (BOARD_SEQ.NEXTVAL, ?, ?, ?, ?, SYSDATE)";
	        pst = conn.prepareStatement(sql);

	        pst.setString(1, category);
	        pst.setString(2, title);
	        pst.setString(3, content);
	        pst.setString(4, userEmpid);

	        int rowsAffected = pst.executeUpdate();
	        if (rowsAffected > 0) {
	            success = true;
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	        // 로그 기록 또는 예외 처리
	    } finally {
	        close(); // 데이터베이스 연결 종료
	    }

	    return success;
	}
	
	public WebMember getEmployeeDetails(String empId) {
	    WebMember member = new WebMember(); // 기본 객체 생성
	    try {
	        connect();
	        String sql = "SELECT m.*, d.DEPT_NAME FROM MEMBER_TB m " +
	                     "LEFT JOIN DEPARTMENT_TB d ON m.DEPT_IDX = d.DEPT_IDX " +
	                     "WHERE m.USER_EMPID = ?";
	        pst = conn.prepareStatement(sql);
	        pst.setString(1, empId);
	        rs = pst.executeQuery();

	        if (rs.next()) {
	            member.setEmpid(rs.getString("USER_EMPID"));
	            member.setName(rs.getString("USER_NAME"));
	            member.setPosition(rs.getString("USER_POSITION"));
	            member.setDeptidx(rs.getString("DEPT_IDX"));
	            member.setDeptName(rs.getString("DEPT_NAME"));
	            member.setPhone(rs.getString("USER_PHONE"));
	            member.setInlinenum(rs.getString("USER_INLINE"));
	            member.setRole(rs.getString("USER_ROLE"));
	        } else {
	            System.out.println("No user found for empId: " + empId);
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	        System.out.println("SQL Error in getEmployeeDetails: " + e.getMessage());
	    } finally {
	        close();
	    }
	    return member; // 항상 WebMember 객체를 반환
	}

	public ArrayList<WebMember> getAllEmployees() {
	    ArrayList<WebMember> employees = new ArrayList<>();
	    try {
	        connect();
	        String sql = "SELECT m.*, d.DEPT_NAME FROM MEMBER_TB m " +
	                     "LEFT JOIN DEPARTMENT_TB d ON m.DEPT_IDX = d.DEPT_IDX";
	        pst = conn.prepareStatement(sql);
	        rs = pst.executeQuery();

	        while (rs.next()) {
	            WebMember member = new WebMember();
	            member.setEmpid(rs.getString("USER_EMPID"));
	            member.setName(rs.getString("USER_NAME"));
	            member.setPosition(rs.getString("USER_POSITION"));
	            member.setDeptidx(rs.getString("DEPT_IDX"));
	            member.setDeptName(rs.getString("DEPT_NAME"));
	            member.setPhone(rs.getString("USER_PHONE"));
	            member.setInlinenum(rs.getString("USER_INLINE"));
	            employees.add(member);
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    } finally {
	        close();
	    }
	    return employees;
    }
    
    public ArrayList<WebMember> getAllDepartments() {
        ArrayList<WebMember> departments = new ArrayList<>();
        connect();
        try {
            String sql = "SELECT DEPT_IDX, DEPT_NAME FROM DEPARTMENT_TB";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();

            while (rs.next()) {
                WebMember dept = new WebMember();
                dept.setDeptidx(rs.getString("DEPT_IDX"));
                dept.setDeptName(rs.getString("DEPT_NAME"));
                departments.add(dept);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            close();
        }
        return departments;
    }
    
    public String getDeptNameById(String deptIdx) {
        String deptName = "";
        try {
            connect();
            String sql = "SELECT DEPT_NAME FROM DEPARTMENT_TB WHERE DEPT_IDX = ?";
            pst = conn.prepareStatement(sql);
            pst.setString(1, deptIdx);
            rs = pst.executeQuery();
            if (rs.next()) {
                deptName = rs.getString("DEPT_NAME");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            close();
        }
        return deptName;
    }
    
    
}
