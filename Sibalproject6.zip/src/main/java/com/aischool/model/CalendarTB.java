package com.aischool.model;

public class CalendarTB {
    private int calIdx;
    private String userEmpId;
    private String calContent;
    private java.sql.Date calDate;
    private String calColor;
    private String calStatus;
    private int deptIdx;
    private String deptManager;

    // Getters and Setters
    public int getCalIdx() {
        return calIdx;
    }

    public void setCalIdx(int calIdx) {
        this.calIdx = calIdx;
    }

    public String getUserEmpId() {
        return userEmpId;
    }

    public void setUserEmpId(String userEmpId) {
        this.userEmpId = userEmpId;
    }

    public String getCalContent() {
        return calContent;
    }

    public void setCalContent(String calContent) {
        this.calContent = calContent;
    }

    public java.sql.Date getCalDate() {
        return calDate;
    }

    public void setCalDate(java.sql.Date calDate) {
        this.calDate = calDate;
    }

    public String getCalColor() {
        return calColor;
    }

    public void setCalColor(String calColor) {
        this.calColor = calColor;
    }

    public String getCalStatus() {
        return calStatus;
    }

    public void setCalStatus(String calStatus) {
        this.calStatus = calStatus;
    }

    public int getDeptIdx() {
        return deptIdx;
    }

    public void setDeptIdx(int deptIdx) {
        this.deptIdx = deptIdx;
    }

    public String getDeptManager() {
        return deptManager;
    }

    public void setDeptManager(String deptManager) {
        this.deptManager = deptManager;
    }
}