package com.aischool.model;

public class DepartmentTB {
	private int dept_idx;
	private String dept_Name;
	private String dept_Location;
	private String dept_Space;
	private String dept_Manager;
	
	public DepartmentTB(int dept_idx, String dept_Name, String dept_Location, String dept_Space, String dept_Manager) {
		super();
		this.dept_idx = dept_idx;
		this.dept_Name = dept_Name;
		this.dept_Location = dept_Location;
		this.dept_Space = dept_Space;
		this.dept_Manager = dept_Manager;
	}

	public DepartmentTB() {
		
	}

	public int getDept_idx() {
		return dept_idx;
	}

	public void setDept_idx(int dept_idx) {
		this.dept_idx = dept_idx;
	}

	public String getDept_Name() {
		return dept_Name;
	}

	public void setDept_Name(String dept_Name) {
		this.dept_Name = dept_Name;
	}

	public String getDept_Location() {
		return dept_Location;
	}

	public void setDept_Location(String dept_Location) {
		this.dept_Location = dept_Location;
	}

	public String getDept_Space() {
		return dept_Space;
	}

	public void setDept_Space(String dept_Space) {
		this.dept_Space = dept_Space;
	}

	public String getDept_Manager() {
		return dept_Manager;
	}

	public void setDept_Manager(String dept_Manager) {
		this.dept_Manager = dept_Manager;
	}
	
	
}
