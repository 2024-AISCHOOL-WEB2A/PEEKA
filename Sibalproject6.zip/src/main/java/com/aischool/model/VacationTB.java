package com.aischool.model;

public class VacationTB {
	private int idx;
	private String empid;
	private String year;
	private double YYoffday; // 연차 통합
	private String dept_manager;
	private String dept_name;
	private String userName;
	private String startDate;
	private String endDate;
	private String reason;
	private String status;

	public VacationTB() {

	}

	public VacationTB(int idx, String empid, String year, double YYoffday, String dept_manager, String dept_name) {
		this.idx = idx;
		this.empid = empid;
		this.year = year;
		this.YYoffday = YYoffday;
		this.dept_manager = dept_manager;
		this.dept_name = dept_name;
		this.status = "PENDING"; // 기본 상태 설정
	}

	public int getIdx() {
		return idx;
	}

	public void setIdx(int idx) {
		this.idx = idx;
	}

	public String getEmpid() {
		return empid;
	}

	public void setEmpid(String empid) {
		this.empid = empid;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public double getYYoffday() {
		return YYoffday;
	}

	public void setYYoffday(double yYoffday) {
		YYoffday = yYoffday;
	}

	public String getDept_manager() {
		return dept_manager;
	}

	public void setDept_manager(String dept_manager) {
		this.dept_manager = dept_manager;
	}

	public String getDept_name() {
		return dept_name;
	}

	public void setDept_name(String dept_name) {
		this.dept_name = dept_name;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }
    
    

}
