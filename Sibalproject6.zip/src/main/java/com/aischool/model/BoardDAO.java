package com.aischool.model;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BoardDAO {
    private Connection conn;
    private PreparedStatement pst;
    private ResultSet rs;

    // 데이터베이스 연결
    private void connect() {
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            String url = "jdbc:oracle:thin:@project-db-stu3.smhrd.com:1524:xe";
            String user = "Insa5_SpringA_hacksim_1";
            String password = "aishcool1";
            conn = DriverManager.getConnection(url, user, password);
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    // 데이터베이스 연결 종료
    private void close() {
        try {
            if (rs != null) rs.close();
            if (pst != null) pst.close();
            if (conn != null) conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // 새 게시글 추가
    public boolean addNotice(BoardTB board) {
        boolean success = false;
        try {
            connect();
            String sql = "INSERT INTO BOARD_TB (BOARD_ID, CATEGORY, TITLE, CONTENT, REG_DATE, USER_EMPID) VALUES (BOARD_SEQ.NEXTVAL, ?, ?, ?, SYSDATE, ?)";
            pst = conn.prepareStatement(sql);
            pst.setString(1, board.getCategory());
            pst.setString(2, board.getTitle());
            pst.setString(3, board.getContent());
            pst.setString(4, board.getUserEmpid());

            int result = pst.executeUpdate();
            if (result > 0) {
                success = true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            close();
        }
        return success;
    }

    // 게시글 목록 조회
    public List<BoardTB> getBoardList() {
        List<BoardTB> boardList = new ArrayList<>();
        try {
            connect();
            String sql = "SELECT * FROM BOARD_TB ORDER BY BOARD_ID DESC";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();

            while (rs.next()) {
                BoardTB board = new BoardTB();
                board.setBoardId(rs.getInt("BOARD_ID"));
                board.setCategory(rs.getString("CATEGORY"));
                board.setTitle(rs.getString("TITLE"));
                board.setContent(rs.getString("CONTENT"));
                board.setRegDate(rs.getDate("REG_DATE"));
                board.setUserEmpid(rs.getString("USER_EMPID"));
                boardList.add(board);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            close();
        }
        return boardList;
    }
    
    public List<BoardTB> getRecentNotices(int limit) {
        List<BoardTB> noticeList = new ArrayList<>();
        try {
            connect();
            String sql = "SELECT * FROM (SELECT * FROM BOARD_TB WHERE CATEGORY = '공지' ORDER BY REG_DATE DESC) WHERE ROWNUM <= ?";
            pst = conn.prepareStatement(sql);
            pst.setInt(1, limit);
            rs = pst.executeQuery();

            while (rs.next()) {
                BoardTB board = new BoardTB();
                board.setBoardId(rs.getInt("BOARD_ID"));
                board.setCategory(rs.getString("CATEGORY"));
                board.setTitle(rs.getString("TITLE"));
                board.setRegDate(rs.getDate("REG_DATE"));
                noticeList.add(board);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            close();
        }
        return noticeList;
    }
    
    public boolean deletePost(int boardId) {
        boolean success = false;
        try {
            connect();
            String sql = "DELETE FROM BOARD_TB WHERE BOARD_ID = ?";
            pst = conn.prepareStatement(sql);
            pst.setInt(1, boardId);

            int result = pst.executeUpdate();
            if (result > 0) {
                success = true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            close();
        }
        return success;
    }
    
    public int getTotalBoardCount() {
        int count = 0;
        try {
            connect();
            String sql = "SELECT COUNT(*) FROM BOARD_TB";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            if (rs.next()) {
                count = rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            close();
        }
        return count;
    }

    public List<BoardTB> getBoardListPaginated(int start, int end) {
        List<BoardTB> boardList = new ArrayList<>();
        try {
            connect();
            String sql = "SELECT * FROM (SELECT b.*, ROW_NUMBER() OVER (ORDER BY BOARD_ID DESC) AS rn FROM BOARD_TB b) WHERE rn BETWEEN ? AND ?";
            pst = conn.prepareStatement(sql);
            pst.setInt(1, start);
            pst.setInt(2, end);
            rs = pst.executeQuery();

            while (rs.next()) {
                BoardTB board = new BoardTB();
                board.setBoardId(rs.getInt("BOARD_ID"));
                board.setCategory(rs.getString("CATEGORY"));
                board.setTitle(rs.getString("TITLE"));
                board.setContent(rs.getString("CONTENT"));
                board.setRegDate(rs.getDate("REG_DATE"));
                board.setUserEmpid(rs.getString("USER_EMPID"));
                boardList.add(board);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            close();
        }
        return boardList;
    }
   
}