package com.aischool.service;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.aischool.model.VacationDAO;

/**
 * Servlet implementation class ApproveVacation
 */
@WebServlet("/ApproveVacation")
public class ApproveVacation extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int vacationId = Integer.parseInt(request.getParameter("vacationId"));
        String action = request.getParameter("action"); // "approve" 또는 "reject"

        VacationDAO vacationDAO = new VacationDAO();
        boolean success = vacationDAO.updateVacationStatus(vacationId, action.toUpperCase());

        if (success) {
            // 직원에게 결과 알림
            notifyEmployee(vacationId, action);
            response.sendRedirect("approve-vacations.jsp");
        } else {
            response.sendRedirect("approval-error.jsp");
        }
    }

    private void notifyEmployee(int vacationId, String action) {
        // 직원에게 승인/거절 결과 알림 로직
    }
}