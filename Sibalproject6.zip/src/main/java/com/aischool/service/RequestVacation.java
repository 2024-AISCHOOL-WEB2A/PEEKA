package com.aischool.service;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.aischool.model.DepartmentDAO;
import com.aischool.model.DepartmentTB;
import com.aischool.model.MemberDAO;
import com.aischool.model.VacationDAO;
import com.aischool.model.VacationTB;
import com.aischool.model.WebMember;

/**
 * Servlet implementation class RequestVacation
 */
@WebServlet("/RequestVacation")
public class RequestVacation extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String empid = request.getParameter("empid");
        String startDate = request.getParameter("startDate");
        String endDate = request.getParameter("endDate");
        String reason = request.getParameter("reason");

        VacationDAO vacationDAO = new VacationDAO();
        DepartmentDAO departmentDAO = new DepartmentDAO();

        WebMember employee = new MemberDAO().getMemberByEmpId(empid);
        DepartmentTB department = departmentDAO.getDepartmentByEmpId(empid);

        VacationTB vacation = new VacationTB();
        vacation.setEmpid(empid);
        vacation.setStartDate(startDate);
        vacation.setEndDate(endDate);
        vacation.setReason(reason);
        vacation.setStatus("PENDING");
        vacation.setDept_manager(department.getDept_Manager());
        vacation.setDept_name(department.getDept_Name());

        boolean success = vacationDAO.addVacation(vacation);

        if (success) {
            response.sendRedirect("vacation-success.jsp");
        } else {
            response.sendRedirect("vacation-error.jsp");
        }
    }
}