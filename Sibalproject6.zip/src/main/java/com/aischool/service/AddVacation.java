package com.aischool.service;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.aischool.model.DepartmentTB;
import com.aischool.model.DepartmentDAO;
import com.aischool.model.VacationDAO;
import com.aischool.model.VacationTB;

@WebServlet("/AddVacation")
public class AddVacation extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        System.out.println("AddVacation 서블릿 시작");
        System.out.println("받은 파라미터: " + request.getParameterMap());

        try {
            String empid = request.getParameter("empid");
            System.out.println("empid: " + empid);

            String year = request.getParameter("year");
            System.out.println("year: " + year);

            double YYoffday = Double.parseDouble(request.getParameter("YYoffday"));
            System.out.println("YYoffday: " + YYoffday);

            String startDate = request.getParameter("startDate");
            System.out.println("startDate: " + startDate);

            String endDate = request.getParameter("endDate");
            System.out.println("endDate: " + endDate);

            String reason = request.getParameter("reason");
            System.out.println("reason: " + reason);

            VacationDAO vacationDAO = new VacationDAO();
            DepartmentDAO departmentDAO = new DepartmentDAO();

            System.out.println("DAO 객체 생성 완료");

            DepartmentTB department = departmentDAO.getDepartmentByEmpId(empid);
            System.out.println("부서 정보 조회 완료: " + (department != null ? department.toString() : "null"));

            if (department != null) {
            	VacationTB vacation = new VacationTB();
            	vacation.setEmpid(empid);
            	vacation.setYear(year);
            	vacation.setYYoffday(YYoffday);
            	vacation.setDept_manager(department.getDept_Manager());
            	vacation.setDept_name(department.getDept_Name());
            	vacation.setStartDate(startDate);
            	vacation.setEndDate(endDate);
            	vacation.setReason(reason);
            	vacation.setStatus("PENDING");
            	System.out.println("생성된 VacationTB 객체: " + vacation);
                
                vacation.setDept_manager(department.getDept_Manager());
                System.out.println("설정된 DEPT_MANAGER: " + vacation.getDept_manager());

                System.out.println("VacationTB 객체 생성 완료: " + vacation.toString());

                boolean success = vacationDAO.addVacation(vacation);

                System.out.println("휴가 신청 결과: " + success);

                if (success) {
                    sendNotificationToManager(department.getDept_Manager(), vacation);
                    response.sendRedirect("facial_recognition3.jsp");
                } else {
                    response.sendRedirect("Attendance.jsp?error=true");
                }
            } else {
                System.out.println("부서 정보를 찾을 수 없음");
                response.sendRedirect("Attendance.jsp?error=department");
            }
        } catch (Exception e) {
            System.out.println("예외 발생: " + e.getMessage());
            e.printStackTrace();
            response.sendRedirect("Attendance.jsp?error=exception");
        }
    }

    private void sendNotificationToManager(String managerEmpId, VacationTB vacation) {
        // 관리자에게 알림을 보내는 로직 구현
        System.out.println("관리자에게 알림 전송: " + managerEmpId);
    }
}