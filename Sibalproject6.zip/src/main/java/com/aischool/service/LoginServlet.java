package com.aischool.service;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.aischool.model.MemberDAO;
import com.aischool.model.WebMember;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String empid = request.getParameter("username");
        String pw = request.getParameter("password");
        
        MemberDAO dao = new MemberDAO();
        WebMember member = new WebMember();
        member.setEmpid(empid);
        member.setPw(pw);
        
        WebMember user = dao.memberLogin(member);
        
        if (user != null) {
            // 로그인 성공
            HttpSession session = request.getSession();
            session.setAttribute("loggedInUser", user);
            response.sendRedirect("facial_recognition.jsp"); // 로그인 성공 시 facial_recognition.jsp로 이동
        } else {
            // 로그인 실패
            response.sendRedirect("Login.jsp?error=true");
        }
    }
}