package com.aischool.service;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.aischool.model.WebMember;

@WebServlet("/FaceRecognitionService")
public class FaceRecognitionService extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		WebMember loggedInUser = (WebMember) session.getAttribute("loggedInUser");

		if (loggedInUser != null) {
			String empid = loggedInUser.getEmpid();
			System.out.println("FaceRecognitionService: Redirecting user with empid: " + empid);
			// Flask 서버의 얼굴 인식 페이지로 리다이렉트 (사용자 ID 포함)
			response.sendRedirect("http://127.0.0.1:5000/?user_empid=" + empid);
		} else {
			System.out.println("FaceRecognitionService: No logged in user found, redirecting to Login.jsp");
			// 로그인되지 않은 경우 로그인 페이지로 리다이렉트
			response.sendRedirect("Login.jsp");
		}
	}

}
