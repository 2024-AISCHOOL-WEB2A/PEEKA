package com.aischool.service;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.aischool.model.BoardDAO;
import com.aischool.model.BoardTB;
import com.aischool.model.MemberDAO;

/**
 * Servlet implementation class SubmitNotice
 */
@WebServlet("/SubmitNotice")
public class SubmitNotice extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        
        String category = request.getParameter("category");
        String title = request.getParameter("title");
        String content = request.getParameter("content");
        String userEmpid = request.getParameter("user_empid");

        BoardTB board = new BoardTB();
        board.setCategory(category);
        board.setTitle(title);
        board.setContent(content);
        board.setUserEmpid(userEmpid);

        BoardDAO dao = new BoardDAO();
        boolean success = dao.addNotice(board);

        if (success) {
            response.sendRedirect("NoticeBoard.jsp");
        } else {
            response.sendRedirect("WriteNotice.jsp?error=true");
        }
    }
}