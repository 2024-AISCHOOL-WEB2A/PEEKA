package com.aischool.service;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.aischool.model.MemberDAO;
import com.aischool.model.WebMember;

@WebServlet("/GetEmployeeServlet")
public class GetEmployeeServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String empId = request.getParameter("empId");
        MemberDAO dao = new MemberDAO();
        WebMember employee = dao.getEmployeeDetails(empId);
        
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        
        PrintWriter out = response.getWriter();
        if (employee != null) {
            String jsonResponse = String.format(
                "{\"name\":\"%s\",\"position\":\"%s\",\"deptName\":\"%s\",\"phone\":\"%s\",\"inlinenum\":\"%s\"}",
                employee.getName() != null ? employee.getName() : "",
                employee.getPosition() != null ? employee.getPosition() : "",
                employee.getDeptName() != null ? employee.getDeptName() : "",
                employee.getPhone() != null ? employee.getPhone() : "",
                employee.getInlinenum() != null ? employee.getInlinenum() : ""
            );
            out.print(jsonResponse);
        } else {
            out.print("{}");
        }
        out.flush();
    }
}