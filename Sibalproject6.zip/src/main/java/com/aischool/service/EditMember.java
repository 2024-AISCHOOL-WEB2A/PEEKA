package com.aischool.service;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.aischool.model.MemberDAO;
import com.aischool.model.WebMember;

@WebServlet("/EditMember")
public class EditMember extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");

		String empId = request.getParameter("empId");
		String name = request.getParameter("name");
		String email = request.getParameter("email");
		String position = request.getParameter("position");
		String deptidx = request.getParameter("deptidx");
		String phone = request.getParameter("phone");
		String inlinenum = request.getParameter("inlinenum");
		String password = request.getParameter("password");

		MemberDAO dao = new MemberDAO();
		WebMember member = new WebMember();
		member.setEmpid(empId);

		// NULL 체크 추가
		if (name != null && !name.trim().isEmpty()) {
			member.setName(name);
		}
		if (email != null && !email.trim().isEmpty()) {
			member.setEmail(email);
		}
		if (position != null && !position.trim().isEmpty()) {
			member.setPosition(position);
		}
		if (deptidx != null && !deptidx.trim().isEmpty()) {
			member.setDeptidx(deptidx);
		}
		if (phone != null && !phone.trim().isEmpty()) {
			member.setPhone(phone);
		}
		if (inlinenum != null && !inlinenum.trim().isEmpty()) {
			member.setInlinenum(inlinenum);
		}
		if (password != null && !password.trim().isEmpty()) {
			member.setPw(password);
		}

		int updateResult = dao.memberUpdate(member);

		if (updateResult > 0) {
			response.sendRedirect("Account.jsp?updateSuccess=true");
		} else {
			response.sendRedirect("EditAccount.jsp?empId=" + empId + "&updateFailed=true");
		}
	}
}