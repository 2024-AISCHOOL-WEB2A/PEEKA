package com.aischool.service;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.aischool.model.MemberDAO;
import com.aischool.model.WebMember;

@WebServlet("/AddMember")
public class AddMember extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        
        String empid = request.getParameter("empid");
        String pw = request.getParameter("pw");
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String birthday = request.getParameter("birthday");
        String hiredate = request.getParameter("hiredate");
        String phone = request.getParameter("phone");
        String inlinenum = request.getParameter("inlinenum");
        String deptName = request.getParameter("deptName"); // 부서 이름을 받습니다
        String position = request.getParameter("position");
        String role = request.getParameter("role");

        WebMember member = new WebMember();
        member.setEmpid(empid);
        member.setPw(pw);
        member.setName(name);
        member.setEmail(email);
        member.setBirthday(birthday);
        member.setHiredate(hiredate);
        member.setPhone(phone);
        member.setInlinenum(inlinenum);
        member.setPosition(position);
        member.setRole(role);

        MemberDAO dao = new MemberDAO();
        int deptIdx = dao.getDeptIdxByName(deptName); // 부서 이름으로 DEPT_IDX를 가져옵니다
        member.setDeptidx(String.valueOf(deptIdx));

        int result = dao.memberJoin(member);

        if (result > 0) {
            // 계정 추가 성공
            response.sendRedirect("Account.jsp");
        } else if (result == -1) {
            // 중복된 empid
            response.sendRedirect("AddAccount.jsp?error=duplicate");
        } else {
            // 기타 오류
            response.sendRedirect("AddAccount.jsp?error=failed");
        }
    }
}