import cv2
import mediapipe as mp
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
import pickle
import os
import random
import time
from PIL import Image, ImageDraw, ImageFont

# MediaPipe Hands 초기화
mp_hands = mp.solutions.hands
hands = mp_hands.Hands(max_num_hands=10)
mp_drawing = mp.solutions.drawing_utils
mp_drawing_styles = mp.solutions.drawing_styles

# 제스처 정의 (모두 한글로)
GESTURES = ['바위', '보', '가위', '엄지척', '엄지내림']

# 한글 폰트 설정
font_path = 'font/NanumGothic.ttf'  # 경로는 시스템에 따라 다를 수 있습니다.
if not os.path.exists(font_path):
    raise FileNotFoundError(f"폰트 파일을 찾을 수 없습니다: {font_path}")

# 한글 텍스트를 이미지에 추가하는 함수
def put_korean_text(image, text, position, font_size, color):
    img_pil = Image.fromarray(image)
    draw = ImageDraw.Draw(img_pil)
    font = ImageFont.truetype(font_path, font_size)
    draw.text(position, text, font=font, fill=color)
    return np.array(img_pil)

# 손의 랜드마크를 추출하는 함수
def extract_landmarks(hand_landmarks):
    return [lm.x for lm in hand_landmarks.landmark] + [lm.y for lm in hand_landmarks.landmark]

# 손의 크기를 계산하는 함수
def calculate_hand_size(hand_landmarks):
    x_coordinates = [lm.x for lm in hand_landmarks.landmark]
    y_coordinates = [lm.y for lm in hand_landmarks.landmark]
    return max(x_coordinates) - min(x_coordinates), max(y_coordinates) - min(y_coordinates)

# 가장 큰 손을 선택하는 함수
def select_largest_hand(multi_hand_landmarks):
    if not multi_hand_landmarks:
        return None
    largest_hand = max(multi_hand_landmarks, 
                       key=lambda landmarks: calculate_hand_size(landmarks)[0] * calculate_hand_size(landmarks)[1])
    return largest_hand

# 데이터 수집 함수
def collect_data():
    cap = cv2.VideoCapture(0)
    data, labels = [], []
    
    print("데이터 수집을 시작합니다. 'ESC' 키를 눌러 언제든지 종료할 수 있습니다.")
    
    for gesture in GESTURES:
        print(f"'{gesture}' 제스처를 준비하세요. 'C'를 눌러 캡처를 시작합니다.")
        while True:
            ret, frame = cap.read()
            frame = cv2.flip(frame, 1)
            frame = put_korean_text(frame, f"{gesture} 제스처를 보여주고 'C'를 누르세요", (10, 30), 30, (0, 255, 0))
            frame = put_korean_text(frame, "ESC: 종료", (10, 70), 30, (0, 0, 255))
            cv2.imshow('데이터 수집', frame)
            key = cv2.waitKey(1) & 0xFF
            if key == ord('c'):
                break
            elif key == 27:  # ESC
                cap.release()
                cv2.destroyAllWindows()
                return np.array(data), np.array(labels)

        samples = 0
        start_time = time.time()
        while time.time() - start_time < 10:  # 10초 동안 데이터 수집
            ret, frame = cap.read()
            frame = cv2.flip(frame, 1)
            frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            results = hands.process(frame_rgb)
            
            if results.multi_hand_landmarks:
                largest_hand = select_largest_hand(results.multi_hand_landmarks)
                if largest_hand:
                    mp_drawing.draw_landmarks(
                        frame, largest_hand, mp_hands.HAND_CONNECTIONS,
                        mp_drawing_styles.get_default_hand_landmarks_style(),
                        mp_drawing_styles.get_default_hand_connections_style())
                    landmarks = extract_landmarks(largest_hand)
                    data.append(landmarks)
                    labels.append(gesture)
                    samples += 1
                
            frame = put_korean_text(frame, f"{gesture}: {samples} 샘플", (10, 30), 30, (0, 255, 0))
            frame = put_korean_text(frame, "ESC: 종료", (10, 70), 30, (0, 0, 255))
            
            # 진행 바를 아래로 이동
            progress = int(510 * (time.time() - start_time) / 10)
            cv2.rectangle(frame, (10, frame.shape[0] - 50), (10 + progress, frame.shape[0] - 30), (0, 255, 0), cv2.FILLED)
            cv2.rectangle(frame, (10, frame.shape[0] - 50), (520, frame.shape[0] - 30), (255, 255, 255), 2)
            
            cv2.imshow('데이터 수집', frame)
            
            if cv2.waitKey(1) & 0xFF == 27:  # ESC
                cap.release()
                cv2.destroyAllWindows()
                return np.array(data), np.array(labels)

        print(f"{gesture}에 대해 {samples}개의 샘플을 수집했습니다.")

    cap.release()
    cv2.destroyAllWindows()
    return np.array(data), np.array(labels)

# 모델 훈련 및 저장 함수
def train_and_save_model(data, labels, filename='hand_gesture_model.pkl'):
    if len(data) == 0 or len(labels) == 0:
        print("수집된 데이터가 없습니다. 모델 훈련을 건너뜁니다.")
        return None

    X_train, X_test, y_train, y_test = train_test_split(data, labels, test_size=0.2, random_state=42)
    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)
    accuracy = model.score(X_test, y_test)
    print(f"모델 정확도: {accuracy:.2f}")
    with open(filename, 'wb') as f:
        pickle.dump(model, f)
    return model

# 모델 불러오기 함수
def load_model(filename='hand_gesture_model.pkl'):
    if os.path.exists(filename):
        with open(filename, 'rb') as f:
            return pickle.load(f)
    return None

# 2차 인증 함수
def perform_2fa():
    model = load_model()
    if model is None:
        print("훈련된 모델을 찾을 수 없습니다. 먼저 모델을 훈련시켜주세요.")
        return

    cap = cv2.VideoCapture(0)
    target_gestures = random.sample(GESTURES, 3)
    current_index = 0
    correct_count = 0
    authentication_active = False
    countdown = 3
    last_correct_time = 0
    feedback_time = 0

    print("2차 인증 시스템: 인증을 위해 3개의 제스처를 수행해야 합니다.")
    print(f"필요한 제스처: {', '.join(target_gestures)}")

    while True:
        ret, frame = cap.read()
        frame = cv2.flip(frame, 1)
        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = hands.process(frame_rgb)

        if authentication_active:
            current_time = time.time()
            if current_time - last_correct_time > 5:  # 5초 동안 correct 제스처 없으면 인증 실패
                authentication_active = False
                feedback_time = current_time
                frame = put_korean_text(frame, "인증 실패. 시간 초과!", (10, frame.shape[0] - 90), 30, (0, 0, 255))
            elif results.multi_hand_landmarks:
                largest_hand = select_largest_hand(results.multi_hand_landmarks)
                if largest_hand:
                    mp_drawing.draw_landmarks(
                        frame, largest_hand, mp_hands.HAND_CONNECTIONS,
                        mp_drawing_styles.get_default_hand_landmarks_style(),
                        mp_drawing_styles.get_default_hand_connections_style())
                    landmarks = extract_landmarks(largest_hand)
                    predicted_gesture = model.predict([landmarks])[0]
                    
                    frame = put_korean_text(frame, f"감지된 제스처: {predicted_gesture}", (10, 30), 30, (0, 255, 0))
                    frame = put_korean_text(frame, f"목표 제스처: {target_gestures[current_index]}", (10, 70), 30, (255, 0, 0))
                    
                    if predicted_gesture == target_gestures[current_index]:
                        correct_count += 1
                        current_index += 1
                        last_correct_time = current_time
                        if current_index < len(target_gestures):
                            frame = put_korean_text(frame, "정확합니다! 다음 제스처", (10, frame.shape[0] - 90), 30, (0, 255, 0))
                        else:
                            authentication_active = False
                            feedback_time = current_time
                            frame = put_korean_text(frame, "인증 성공!", (10, frame.shape[0] - 90), 30, (0, 255, 0))
                            print("2차 인증 성공! 인증이 완료되었습니다.")
            
            # 남은 시간 표시 (아래로 이동)
            time_left = max(0, 5 - (current_time - last_correct_time))
            progress = int(510 * time_left / 5)
            cv2.rectangle(frame, (10, frame.shape[0] - 50), (10 + progress, frame.shape[0] - 30), (0, 255, 0), cv2.FILLED)
            cv2.rectangle(frame, (10, frame.shape[0] - 50), (520, frame.shape[0] - 30), (255, 255, 255), 2)

        elif countdown > 0:
            frame = put_korean_text(frame, f"{countdown}초 후 시작합니다", (10, frame.shape[0] - 90), 30, (0, 255, 0))
            countdown -= 1
            time.sleep(1)
        elif countdown == 0:
            authentication_active = True
            last_correct_time = time.time()
            countdown = -1
        elif time.time() - feedback_time < 3:  # 인증 결과를 3초간 표시
            if correct_count == 3:
                frame = put_korean_text(frame, "인증 성공!", (10, frame.shape[0] - 90), 30, (0, 255, 0))
            else:
                frame = put_korean_text(frame, "인증 실패.", (10, frame.shape[0] - 90), 30, (0, 0, 255))
        else:
            frame = put_korean_text(frame, "2차 인증을 시작하려면 'S'를 누르세요", (10, frame.shape[0] - 90), 30, (0, 255, 0))

        cv2.imshow('2차 인증 시스템', frame)

        key = cv2.waitKey(1) & 0xFF
        if key == ord('s') and not authentication_active and countdown == -1:
            target_gestures = random.sample(GESTURES, 3)
            current_index = 0
            correct_count = 0
            countdown = 3
            print(f"새로운 인증 시퀀스: {', '.join(target_gestures)}")
        elif key == 27:  # ESC
            break

    cap.release()
    cv2.destroyAllWindows()

# 메인 실행 부분
if __name__ == "__main__":
    while True:
        choice = input("옵션을 선택하세요 (1: 모델 훈련, 2: 2차 인증 수행, 3: 종료): ")
        if choice == '1':
            print("모델 훈련을 위한 데이터를 수집합니다...")
            data, labels = collect_data()
            if len(data) > 0 and len(labels) > 0:
                train_and_save_model(data, labels)
            else:
                print("데이터 수집이 취소되었습니다.")
        elif choice == '2':
            print("2차 인증 프로세스를 시작합니다...")
            perform_2fa()
        elif choice == '3':
            print("프로그램을 종료합니다.")
            break
        else:
            print("잘못된 입력입니다. 다시 시도해주세요.")