import cv2
import mediapipe as mp
import numpy as np
from sklearn.ensemble import RandomForestClassifier
import pickle
import os
import random
import time
from PIL import Image, ImageDraw, ImageFont
from flask import Flask, render_template, Response, jsonify, request

app = Flask(__name__)

# MediaPipe Hands 초기화
mp_hands = mp.solutions.hands
hands = mp_hands.Hands(max_num_hands=10)
mp_drawing = mp.solutions.drawing_utils
mp_drawing_styles = mp.solutions.drawing_styles

# 제스처 정의
GESTURES = ['바위', '보', '가위', '엄지척', '엄지내림']

# 한글 폰트 설정
font_path = 'font/NanumGothic.ttf'
if not os.path.exists(font_path):
    raise FileNotFoundError(f"폰트 파일을 찾을 수 없습니다: {font_path}")

# 전역 변수
model = None
game_state = {
    'active': False,
    'target_gestures': [],
    'current_index': 0,
    'correct_count': 0,
    'last_correct_time': 0,
    'feedback': '',
    'delay': 0
}

# 한글 텍스트를 이미지에 추가하는 함수
def put_korean_text(image, text, position, font_size, color):
    img_pil = Image.fromarray(image)
    draw = ImageDraw.Draw(img_pil)
    font = ImageFont.truetype(font_path, font_size)
    draw.text(position, text, font=font, fill=color)
    return np.array(img_pil)

# 손의 랜드마크를 추출하는 함수
def extract_landmarks(hand_landmarks):
    return [lm.x for lm in hand_landmarks.landmark] + [lm.y for lm in hand_landmarks.landmark]

# 손의 크기를 계산하는 함수
def calculate_hand_size(hand_landmarks):
    x_coordinates = [lm.x for lm in hand_landmarks.landmark]
    y_coordinates = [lm.y for lm in hand_landmarks.landmark]
    return max(x_coordinates) - min(x_coordinates), max(y_coordinates) - min(y_coordinates)

# 가장 큰 손을 선택하는 함수
def select_largest_hand(multi_hand_landmarks):
    if not multi_hand_landmarks:
        return None
    largest_hand = max(multi_hand_landmarks, 
                       key=lambda landmarks: calculate_hand_size(landmarks)[0] * calculate_hand_size(landmarks)[1])
    return largest_hand

def load_model(filename='hand_gesture_model.pkl'):
    global model
    if os.path.exists(filename):
        with open(filename, 'rb') as f:
            model = pickle.load(f)
        return "모델을 성공적으로 로드했습니다."
    return "모델 파일을 찾을 수 없습니다."

def process_frame(frame):
    global game_state, model

    frame = cv2.flip(frame, 1)
    frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    results = hands.process(frame_rgb)

    if game_state['active']:
        current_time = time.time()
        if game_state['delay'] > 0:
            frame = put_korean_text(frame, "다음 제스처 준비", (10, 70), 30, (0, 255, 0))
        elif results.multi_hand_landmarks:
            largest_hand = select_largest_hand(results.multi_hand_landmarks)
            if largest_hand:
                mp_drawing.draw_landmarks(
                    frame, largest_hand, mp_hands.HAND_CONNECTIONS,
                    mp_drawing_styles.get_default_hand_landmarks_style(),
                    mp_drawing_styles.get_default_hand_connections_style())
                landmarks = extract_landmarks(largest_hand)
                predicted_gesture = model.predict([landmarks])[0]
                
                frame = put_korean_text(frame, f"감지된 제스처: {predicted_gesture}", (10, 30), 30, (0, 255, 0))
                frame = put_korean_text(frame, f"목표 제스처: {game_state['target_gestures'][game_state['current_index']]}", (10, 70), 30, (255, 0, 0))
                
                if predicted_gesture == game_state['target_gestures'][game_state['current_index']]:
                    game_state['correct_count'] += 1
                    game_state['current_index'] += 1
                    game_state['delay'] = 3  # 3초 딜레이 설정
                    if game_state['current_index'] < len(game_state['target_gestures']):
                        game_state['feedback'] = "정확합니다! 다음 제스처 준비"
                    else:
                        game_state['active'] = False
                        game_state['feedback'] = "인증 성공!"

        # 남은 시간 표시 (딜레이 중에는 표시하지 않음)
        if game_state['delay'] == 0:
            time_left = max(0, 5 - (current_time - game_state['last_correct_time']))
            progress = int(510 * time_left / 5)
            cv2.rectangle(frame, (10, frame.shape[0] - 50), (10 + progress, frame.shape[0] - 30), (0, 255, 0), cv2.FILLED)
            cv2.rectangle(frame, (10, frame.shape[0] - 50), (520, frame.shape[0] - 30), (255, 255, 255), 2)

    if game_state['feedback']:
        frame = put_korean_text(frame, game_state['feedback'], (10, frame.shape[0] - 90), 30, (0, 255, 0))
    
    return frame

def gen_frames():
    camera = cv2.VideoCapture(0)
    last_time = time.time()
    while True:
        success, frame = camera.read()
        if not success:
            break
        else:
            current_time = time.time()
            if current_time - last_time >= 1:
                if game_state['delay'] > 0:
                    game_state['delay'] -= 1
                    if game_state['delay'] == 0:
                        game_state['last_correct_time'] = current_time
                last_time = current_time

            frame = process_frame(frame)
            ret, buffer = cv2.imencode('.jpg', frame)
            frame = buffer.tobytes()
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')

@app.route('/')
def index():
    return render_template('hand_index.html')

@app.route('/account')
def account():
    return render_template('hand_index_account.html')

@app.route('/vacation')
def vacation():
    return render_template('hand_index_vacation.html')

@app.route('/video_feed')
def video_feed():
    return Response(gen_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/start_game', methods=['POST'])
def start_game():
    global game_state
    if model is None:
        return jsonify({'success': False, 'message': '모델이 로드되지 않았습니다. 먼저 모델을 훈련하세요.'})
    
    game_state['active'] = True
    game_state['target_gestures'] = random.sample(GESTURES, 3)
    game_state['current_index'] = 0
    game_state['correct_count'] = 0
    game_state['feedback'] = '게임 시작! 첫 번째 제스처를 취하세요.'
    game_state['delay'] = 0
    game_state['last_correct_time'] = time.time()
    
    return jsonify({'success': True, 'message': '게임이 시작되었습니다.', 'target_gestures': game_state['target_gestures']})

@app.route('/game_status')
def game_status():
    global game_state
    success = game_state['correct_count'] == len(game_state['target_gestures'])
    return jsonify({
        'active': game_state['active'],
        'feedback': game_state['feedback'],
        'current_index': game_state['current_index'],
        'target_gestures': game_state['target_gestures'],
        'success': success
    })

if __name__ == '__main__':
    load_model()  # 시작 시 모델 로드
    app.run(host='0.0.0.0', port=5001, debug=True)