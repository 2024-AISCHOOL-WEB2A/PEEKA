import cv2
import mediapipe as mp
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.metrics import confusion_matrix, classification_report, accuracy_score
from sklearn.preprocessing import StandardScaler
from imblearn.over_sampling import SMOTE
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout
from tensorflow.keras.utils import to_categorical
import pickle
import os
import random
import time
from PIL import Image, ImageDraw, ImageFont
import seaborn as sns
import matplotlib.pyplot as plt

# MediaPipe Hands 초기화
mp_hands = mp.solutions.hands
hands = mp_hands.Hands(max_num_hands=1, min_detection_confidence=0.7, min_tracking_confidence=0.7)
mp_drawing = mp.solutions.drawing_utils

# 제스처 정의
GESTURES = ['바위', '보', '가위', '엄지척', '엄지내림']

# 데이터 증강 함수
def augment_data(landmarks):
    augmented = []
    # 원본 데이터 추가
    augmented.append(landmarks)
    # 좌우 반전
    flipped = [1 - l if i % 3 == 0 else l for i, l in enumerate(landmarks)]
    augmented.append(flipped)
    # 약간의 회전 (예: -15도에서 15도 사이)
    for _ in range(2):
        angle = np.random.uniform(-15, 15)
        rotated = rotate_landmarks(landmarks, angle)
        augmented.append(rotated)
    # 약간의 크기 변경 (예: 0.9에서 1.1 사이)
    for _ in range(2):
        scale = np.random.uniform(0.9, 1.1)
        scaled = [l * scale for l in landmarks]
        augmented.append(scaled)
    return augmented

# 랜드마크 회전 함수
def rotate_landmarks(landmarks, angle):
    angle_rad = np.radians(angle)
    cos_val = np.cos(angle_rad)
    sin_val = np.sin(angle_rad)
    cx, cy = 0.5, 0.5
    new_landmarks = []
    for i in range(0, len(landmarks), 3):
        x, y = landmarks[i:i+2]
        x_rot = (x - cx) * cos_val - (y - cy) * sin_val + cx
        y_rot = (x - cx) * sin_val + (y - cy) * cos_val + cy
        new_landmarks.extend([x_rot, y_rot, landmarks[i+2]])
    return new_landmarks

# 특성 추출 함수 개선
def extract_features(hand_landmarks):
    if hand_landmarks is None:
        return None
    
    # 기본 좌표 추출
    coords = [[lm.x, lm.y, lm.z] for lm in hand_landmarks.landmark]
    
    # 손가락 길이 계산
    finger_lengths = []
    for finger in [[0,1,2,3,4], [0,5,6,7,8], [0,9,10,11,12], [0,13,14,15,16], [0,17,18,19,20]]:
        length = sum(np.linalg.norm(np.array(coords[finger[i]]) - np.array(coords[finger[i+1]]))
                     for i in range(len(finger)-1))
        finger_lengths.append(length)
    
    # 손가락 각도 계산
    finger_angles = []
    for finger in [[1,2,3,4], [5,6,7,8], [9,10,11,12], [13,14,15,16], [17,18,19,20]]:
        angle = calculate_angle(coords[finger[1]], coords[finger[2]], coords[finger[3]])
        finger_angles.append(angle)
    
    # 손바닥 면적 계산
    palm_area = calculate_triangle_area(coords[0], coords[5], coords[17])
    
    # 모든 특성 결합
    features = [coord for point in coords for coord in point]
    features.extend(finger_lengths)
    features.extend(finger_angles)
    features.append(palm_area)
    
    return features

# 각도 계산 함수
def calculate_angle(a, b, c):
    ba = np.array(a) - np.array(b)
    bc = np.array(c) - np.array(b)
    cosine_angle = np.dot(ba, bc) / (np.linalg.norm(ba) * np.linalg.norm(bc))
    angle = np.arccos(cosine_angle)
    return np.degrees(angle)

# 삼각형 면적 계산 함수
def calculate_triangle_area(a, b, c):
    return 0.5 * abs(a[0]*(b[1]-c[1]) + b[0]*(c[1]-a[1]) + c[0]*(a[1]-b[1]))

# 데이터 수집 함수 (수정됨)
def collect_data(existing_data=None, existing_labels=None):
    data = list(existing_data) if existing_data is not None else []
    labels = list(existing_labels) if existing_labels is not None else []
    
    cap = cv2.VideoCapture(0)
    
    for gesture in GESTURES:
        print(f"'{gesture}' 제스처를 준비하세요. 'C'를 눌러 캡처를 시작합니다.")
        while True:
            ret, frame = cap.read()
            if not ret:
                continue
            frame = cv2.flip(frame, 1)
            rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            results = hands.process(rgb_frame)
            
            if results.multi_hand_landmarks:
                for hand_landmarks in results.multi_hand_landmarks:
                    mp_drawing.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)
            
            cv2.putText(frame, f"Prepare '{gesture}' gesture and press 'C'", (10, 50), 
                        cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
            cv2.imshow('Frame', frame)
            
            key = cv2.waitKey(1)
            if key == ord('c'):
                break
            elif key == 27:  # ESC
                cap.release()
                cv2.destroyAllWindows()
                return data, labels
        
        print(f"Capturing {gesture} gesture. Press 'Q' to stop.")
        count = 0
        while count < 100:  # Capture 100 samples for each gesture
            ret, frame = cap.read()
            if not ret:
                continue
            frame = cv2.flip(frame, 1)
            rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            results = hands.process(rgb_frame)
            
            if results.multi_hand_landmarks:
                hand_landmarks = results.multi_hand_landmarks[0]  # Assuming only one hand
                features = extract_features(hand_landmarks)
                if features:
                    augmented_features = augment_data(features)
                    data.extend(augmented_features)
                    labels.extend([gesture] * len(augmented_features))
                    count += 1
                
                mp_drawing.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)
            
            cv2.putText(frame, f"Capturing {gesture}: {count}/100", (10, 50), 
                        cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
            cv2.imshow('Frame', frame)
            
            if cv2.waitKey(1) == ord('q'):
                break
    
    cap.release()
    cv2.destroyAllWindows()
    return data, labels

# 새로운 모델 정의 (딥러닝 모델)
def create_model(input_shape, num_classes):
    model = Sequential([
        Dense(128, activation='relu', input_shape=(input_shape,)),
        Dropout(0.3),
        Dense(64, activation='relu'),
        Dropout(0.3),
        Dense(32, activation='relu'),
        Dense(num_classes, activation='softmax')
    ])
    model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
    return model

# 모델 훈련 및 저장 함수 (수정됨)
def train_and_save_model(data, labels, filename='hand_gesture_model.h5'):
    if len(data) == 0 or len(labels) == 0:
        print("수집된 데이터가 없습니다. 모델 훈련을 건너뜁니다.")
        return None

    # 데이터 전처리
    X = np.array(data)
    y = np.array(labels)
    
    # 클래스 불균형 처리
    smote = SMOTE(random_state=42)
    X, y = smote.fit_resample(X, y)
    
    # 데이터 정규화
    scaler = StandardScaler()
    X = scaler.fit_transform(X)
    
    # 레이블 인코딩
    y = to_categorical(np.unique(y, return_inverse=True)[1])
    
    # 데이터 분할
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    # 모델 생성 및 훈련
    model = create_model(X.shape[1], len(GESTURES))
    history = model.fit(X_train, y_train, validation_split=0.2, epochs=100, batch_size=32, verbose=1)
    
    # 모델 평가
    loss, accuracy = model.evaluate(X_test, y_test, verbose=0)
    print(f"Test accuracy: {accuracy:.4f}")
    
    # 모델 저장
    model.save(filename)
    
    # 혼동 행렬 및 분류 보고서
    y_pred = model.predict(X_test)
    y_pred_classes = np.argmax(y_pred, axis=1)
    y_true = np.argmax(y_test, axis=1)
    
    cm = confusion_matrix(y_true, y_pred_classes)
    plt.figure(figsize=(10, 8))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues')
    plt.title('Confusion Matrix')
    plt.xlabel('Predicted')
    plt.ylabel('Actual')
    plt.savefig('confusion_matrix.png')
    plt.close()
    
    print("Classification Report:")
    print(classification_report(y_true, y_pred_classes, target_names=GESTURES))
    
    return model, scaler

# 메인 실행 부분 (수정됨)
if __name__ == "__main__":
    all_data = []
    all_labels = []
    model = None
    scaler = None
    
    while True:
        choice = input("옵션을 선택하세요 (1: 모델 훈련, 2: 2차 인증 수행 및 평가, 3: 종료): ")
        if choice == '1':
            print("모델 훈련을 위한 데이터를 수집합니다...")
            all_data, all_labels = collect_data(all_data, all_labels)
            if len(all_data) > 0 and len(all_labels) > 0:
                model, scaler = train_and_save_model(all_data, all_labels)
        elif choice == '2':
            if model is None:
                print("먼저 모델을 훈련시켜야 합니다. 옵션 1을 선택하여 모델을 훈련시켜주세요.")
            else:
                print("2차 인증 프로세스를 시작합니다...")
                perform_2fa(model, scaler)
        elif choice == '3':
            print("프로그램을 종료합니다.")
            break
        else:
            print("잘못된 입력입니다. 다시 시도해주세요.")