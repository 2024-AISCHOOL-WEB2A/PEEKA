import logging
from flask import Flask, render_template, request, jsonify, Response
from flask_cors import CORS
import cv2
import dlib
import datetime
import os
import numpy as np
import boto3
from botocore.exceptions import ClientError

# cx_Oracle 임포트 시도
try:
    import cx_Oracle
except ImportError:
    logging.error("cx_Oracle 라이브러리가 설치되어 있지 않습니다. 'pip install cx_Oracle'를 실행하여 설치해주세요.")
    cx_Oracle = None

app = Flask(__name__)
CORS(app)  # CORS 지원 추가

# 로깅 설정을 DEBUG로 변경
logging.basicConfig(level=logging.DEBUG)

# dlib의 얼굴 감지기 초기화
detector = dlib.get_frontal_face_detector()

# AWS 설정
aws_access_key_id = 'AKIAZI2LEXP6FRVMQQAP'
aws_secret_access_key = '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'
region_name = 'us-east-2'

# AWS 세션 생성
session = boto3.Session(
    aws_access_key_id=aws_access_key_id,
    aws_secret_access_key=aws_secret_access_key,
    region_name=region_name
)

# AWS Rekognition 클라이언트 설정
client = session.client('rekognition')

# AWS S3 클라이언트 설정
s3 = session.client('s3')

# 하드코딩된 파일 정보
# def get_file_info():
#     return {
#         'file_name': 'test',
#         'file_ext': 'jpg',
#         'file_path': 'https://peekatest.s3.us-east-2.amazonaws.com/test.jpg'
#     }

# 오라클 데이터베이스 연결 설정
def get_db_connection():
    try:
        dsn = cx_Oracle.makedsn("project-db-stu3.smhrd.com", "1524", sid="xe")
        return cx_Oracle.connect(
            "Insa5_SpringA_hacksim_1", "aishcool1", dsn
        )
    except cx_Oracle.Error as error:
        logging.error(f"데이터베이스 연결 오류: {error}")
        return None
    
# 파일 정보 가져오기
def get_file_info(user_empid):
    if cx_Oracle is None:
        logging.error("cx_Oracle 라이브러리가 설치되어 있지 않아 데이터베이스 연결을 할 수 없습니다.")
        return None
    
    connection = get_db_connection()
    if connection is None:
        return None
    
    cursor = connection.cursor()
    
    try:
        cursor.execute("SELECT * FROM face_image_tb WHERE USER_EMPID = :empid", empid=user_empid)
        row = cursor.fetchone()
        if row:
            return {
                'file_name': row[0],
                'file_ext': row[1],
                'file_path': row[2],
                'file_empid': row[3]
            }
        else:
            logging.warning(f"데이터베이스에서 사용자 ID {user_empid}의 파일 정보를 찾을 수 없습니다.")
            return None
        
    except cx_Oracle.Error as error:
        logging.error(f"데이터베이스 쿼리 실행 오류: {error}")
        return None
    
    finally:
        cursor.close()
        connection.close()

def detect_and_mark_face(image):
    rgb_image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    dets, scores, _ = detector.run(rgb_image, 1, 0)
    
    if len(dets) > 0:
        face = max(dets, key=lambda d: (d.right() - d.left()) * (d.bottom() - d.top()))
        
        x, y = face.left(), face.top()
        w, h = face.right() - face.left(), face.bottom() - face.top()

        padding = int(w * 0.1)
        x = max(0, x - padding)
        y = max(0, y - padding)
        w = min(image.shape[1] - x, w + 2 * padding)
        h = min(image.shape[0] - y, h + 2 * padding)
        
        cv2.rectangle(image, (x, y), (x+w, y+h), (0, 255, 0), 2)
        
        face_image = image[y:y+h, x:x+w]
        return image, face_image, True
    
    return image, None, False

def gen_frames():
    camera = cv2.VideoCapture(0)
    while True:
        success, frame = camera.read()
        if not success:
            break
        else:
            marked_frame, _, face_detected = detect_and_mark_face(frame)
            if face_detected:
                cv2.putText(marked_frame, "Face Detected", (10, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
            ret, buffer = cv2.imencode('.jpg', marked_frame)
            frame = buffer.tobytes()
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')

def compare_faces(client, source_image_bytes, target_image_bytes, similarity_threshold):
    response = client.compare_faces(
        SimilarityThreshold=similarity_threshold,
        SourceImage={'Bytes': source_image_bytes},
        TargetImage={'Bytes': target_image_bytes}
    )
    return response


@app.route('/')
def index():
    user_empid = request.args.get('user_empid')
    logging.debug(f"Received request for index with user_empid: {user_empid}")
    return render_template('face_index.html', user_empid=user_empid)


@app.route('/account')
def account():
    user_empid = request.args.get('user_empid')
    logging.debug(f"Received request for account with user_empid: {user_empid}")
    
    if not user_empid:
        logging.warning("No user_empid provided in account route")
        # user_empid가 없을 경우 처리 (예: 에러 페이지로 리다이렉트)
        return render_template('error.html', message="사용자 ID가 제공되지 않았습니다.")
    
    # 여기에 user_empid를 사용한 추가 로직을 구현할 수 있습니다.
    # 예: 데이터베이스에서 사용자 정보 조회
    
    return render_template('face_index_account.html', user_empid=user_empid)

@app.route('/vacation')
def vacation():
    user_empid = request.args.get('user_empid')
    logging.debug(f"Received request for account with user_empid: {user_empid}")
    
    if not user_empid:
        logging.warning("No user_empid provided in account route")
        # user_empid가 없을 경우 처리 (예: 에러 페이지로 리다이렉트)
        return render_template('error.html', message="사용자 ID가 제공되지 않았습니다.")
    
    # 여기에 user_empid를 사용한 추가 로직을 구현할 수 있습니다.
    # 예: 데이터베이스에서 사용자 정보 조회
    
    return render_template('face_index_vacation.html', user_empid=user_empid)

@app.route('/video_feed')
def video_feed():
    return Response(gen_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/capture', methods=["POST"])
def capture():
    user_empid = request.form.get('user_empid')  # POST 요청에서 user_empid를 가져옵니다.
    logging.debug(f"Received capture request with user_empid: {user_empid}")

    if not user_empid:
        logging.warning("No user_empid found in the request")
        return jsonify({"success": False, "message": "사용자 정보를 찾을 수 없습니다."})
    
    if 'image' not in request.files:
        logging.warning("No file part in the request")
        return jsonify({
            "success": False, 
            "message": "No file part"
        })
    
    file = request.files['image']
    
    if file.filename == '':
        logging.warning("No selected file")
        return jsonify({
            "success": False, 
            "message": "No selected file"
        })
    
    try:
        # 이미지 읽기 및 디코딩
        nparr = np.frombuffer(file.read(), np.uint8)
        image = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        
        # 이미지 디코딩 확인
        if image is None:
            logging.error("Failed to decode the image")
            return jsonify({"success": False, "message": "이미지를 디코딩할 수 없습니다."})
        
        # 이미지 형식 로깅
        logging.debug(f"Image shape after decoding: {image.shape}, dtype: {image.dtype}")
        
        # 이미지를 8비트 RGB로 명시적 변환
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        
        
        marked_image, face_image, face_detected = detect_and_mark_face(image)
        
        logging.info(f"Face detected: {face_detected}")
        
        if face_detected:
            now = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
            filename_face = f"face_{now}.jpg"
            filepath_face = os.path.join('static/upload', filename_face)
            
            cv2.imwrite(filepath_face, face_image)
            logging.info(f"Face image saved: {filepath_face}")
            
            with open(filepath_face, 'rb') as captured_file:
                captured_image_bytes = captured_file.read()
            
            file_info = get_file_info(user_empid)
            logging.debug(f"File info for user {user_empid}: {file_info}")
            if not file_info:
                logging.warning(f"No file info found for user {user_empid}")
                return jsonify({
                    "success": False,
                    "message": f"사용자 ID {user_empid}의 파일 정보를 데이터베이스에서 가져올 수 없습니다."
            })

            try:
                s3_key = f"{file_info['file_empid']}.{file_info['file_ext']}"
                response = s3.get_object(Bucket='peekatest', Key=s3_key)
                source_image_bytes = response['Body'].read()
            except ClientError as e:
                logging.error(f"Error retrieving image from S3: {str(e)}")
                return jsonify({
                    "success": False,
                    "message": f"S3에서 이미지를 가져오는 중 오류 발생: {str(e)}"
                })

            similarity_threshold = 95
            try:
                response = compare_faces(client, source_image_bytes, captured_image_bytes, similarity_threshold)

                matched = False
                highest_similarity = 0.0
                for face_match in response['FaceMatches']:
                    similarity = face_match['Similarity']
                    if similarity > highest_similarity:
                        highest_similarity = similarity
                    if similarity >= similarity_threshold:
                        matched = True

                if matched:
                    logging.info(f"Face matched with similarity: {highest_similarity:.2f}%")

                    return jsonify({
                        "success": True,
                        "message": f"얼굴이 인식되었습니다. 유사도: {highest_similarity:.2f}%",

                    })
                else:
                    logging.info(f"Face not matched. Highest similarity: {highest_similarity:.2f}%")
                    return jsonify({
                        "success": False,
                        "message": f"얼굴이 일치하지 않습니다. 유사도: {highest_similarity:.2f}%"
                    })
            except Exception as e:
                logging.error(f"Error during face comparison: {str(e)}")
                return jsonify({
                    "success": False,
                    "message": f"얼굴 비교 중 오류 발생: {str(e)}"
                })
        else:
            logging.info("No face detected in the image")
            return jsonify({
                "success": False,
                "message": "얼굴이 감지되지 않았습니다. 얼굴을 가리는 물체를 제거하고 다시 시도해주세요."
            })
    except Exception as e:
        logging.error(f"Error during image processing: {str(e)}")
        return jsonify({
            "success": False,
            "message": f"이미지 처리 중 오류 발생: {str(e)}"
        })

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)